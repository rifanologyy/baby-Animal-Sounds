
import React from 'react';
import Header from './components/Header';
import AnimalCard from './components/AnimalCard';
import { ANIMALS } from './constants';

const App: React.FC = () => {
  return (
    <div className="min-h-screen w-full flex flex-col items-center p-4">
      <Header />
      <main className="flex-grow w-full max-w-4xl mx-auto">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 sm:gap-6 md:gap-8">
          {ANIMALS.map((animal) => (
            <AnimalCard key={animal.name} animal={animal} />
          ))}
        </div>
      </main>
      <footer className="text-center py-4 text-gray-500 text-sm">
        <p>Made with ❤️ for the little ones.</p>
      </footer>
    </div>
  );
};

export default App;
