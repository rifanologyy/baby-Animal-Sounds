
export interface Animal {
  name: string;
  emoji: string;
  bgColor: string;
  hoverColor: string;
  textColor: string;
  sound: () => void;
}
