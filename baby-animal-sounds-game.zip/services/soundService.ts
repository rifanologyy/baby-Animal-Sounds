
// A global AudioContext to be reused.
let audioContext: AudioContext | null = null;

const getAudioContext = (): AudioContext | null => {
  if (typeof window === 'undefined') return null;
  if (!audioContext) {
    try {
      audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    } catch (e) {
      console.error("Web Audio API is not supported in this browser", e);
      return null;
    }
  }
  return audioContext;
};

const playSound = (nodes: (ctx: AudioContext, time: number) => void, duration: number) => {
  const context = getAudioContext();
  if (!context) return;
  
  // Resume context if it's suspended (e.g., due to browser autoplay policies)
  if (context.state === 'suspended') {
    context.resume();
  }

  nodes(context, context.currentTime);
};

export const playCowSound = () => {
  playSound((context, time) => {
    const oscillator = context.createOscillator();
    const gainNode = context.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(context.destination);

    oscillator.type = 'sawtooth';
    oscillator.frequency.setValueAtTime(120, time);
    oscillator.frequency.linearRampToValueAtTime(100, time + 0.4);

    gainNode.gain.setValueAtTime(0.3, time);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, time + 0.5);

    oscillator.start(time);
    oscillator.stop(time + 0.5);
  }, 0.5);
};

export const playDuckSound = () => {
  playSound((context, time) => {
    const oscillator = context.createOscillator();
    const gainNode = context.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(context.destination);

    oscillator.type = 'square';
    oscillator.frequency.setValueAtTime(800, time);
    
    gainNode.gain.setValueAtTime(0.2, time);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, time + 0.2);

    oscillator.start(time);
    oscillator.stop(time + 0.2);
  }, 0.2);
};

export const playCatSound = () => {
  playSound((context, time) => {
    const oscillator = context.createOscillator();
    const gainNode = context.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(context.destination);
    
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(700, time);
    oscillator.frequency.exponentialRampToValueAtTime(1200, time + 0.2);
    oscillator.frequency.exponentialRampToValueAtTime(800, time + 0.4);

    gainNode.gain.setValueAtTime(0.3, time);
    gainNode.gain.linearRampToValueAtTime(0, time + 0.4);
    
    oscillator.start(time);
    oscillator.stop(time + 0.4);
  }, 0.4);
};

export const playDogSound = () => {
   playSound((context, time) => {
    const oscillator = context.createOscillator();
    const gainNode = context.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(context.destination);

    oscillator.type = 'square';
    oscillator.frequency.setValueAtTime(300, time);
    gainNode.gain.setValueAtTime(0.4, time);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, time + 0.1);
    
    oscillator.start(time);
    oscillator.stop(time + 0.1);

    setTimeout(() => {
        const o2 = context.createOscillator();
        const g2 = context.createGain();
        o2.connect(g2);
        g2.connect(context.destination);
        o2.type = 'square';
        o2.frequency.setValueAtTime(250, time + 0.15);
        g2.gain.setValueAtTime(0.4, time + 0.15);
        g2.gain.exponentialRampToValueAtTime(0.0001, time + 0.3);
        o2.start(time + 0.15);
        o2.stop(time + 0.3);
    }, 150);
  }, 0.3);
};


export const playSheepSound = () => {
  playSound((context, time) => {
    const oscillator = context.createOscillator();
    const gainNode = context.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(context.destination);
    
    oscillator.type = 'triangle';
    oscillator.frequency.setValueAtTime(400, time);
    oscillator.frequency.setValueAtTime(440, time + 0.2);
    oscillator.frequency.setValueAtTime(390, time + 0.4);

    gainNode.gain.setValueAtTime(0.3, time);
    gainNode.gain.linearRampToValueAtTime(0, time + 0.5);
    
    oscillator.start(time);
    oscillator.stop(time + 0.5);
  }, 0.5);
};


export const playBirdSound = () => {
  playSound((context, time) => {
    const oscillator = context.createOscillator();
    const gainNode = context.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(context.destination);
    
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(2500, time);
    oscillator.frequency.linearRampToValueAtTime(3500, time + 0.1);
    oscillator.frequency.linearRampToValueAtTime(2000, time + 0.2);

    gainNode.gain.setValueAtTime(0.2, time);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, time + 0.2);
    
    oscillator.start(time);
    oscillator.stop(time + 0.2);
  }, 0.2);
};
