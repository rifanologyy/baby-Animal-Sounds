
import { Animal } from './types';
import * as soundService from './services/soundService';

export const ANIMALS: Animal[] = [
  {
    name: 'Cow',
    emoji: '🐄',
    bgColor: 'bg-stone-300',
    hoverColor: 'hover:bg-stone-400',
    textColor: 'text-stone-800',
    sound: soundService.playCowSound,
  },
  {
    name: 'Duck',
    emoji: '🦆',
    bgColor: 'bg-yellow-400',
    hoverColor: 'hover:bg-yellow-500',
    textColor: 'text-yellow-900',
    sound: soundService.playDuckSound,
  },
  {
    name: 'Cat',
    emoji: '🐈',
    bgColor: 'bg-orange-400',
    hoverColor: 'hover:bg-orange-500',
    textColor: 'text-orange-900',
    sound: soundService.playCatSound,
  },
  {
    name: 'Dog',
    emoji: '🐕',
    bgColor: 'bg-sky-400',
    hoverColor: 'hover:bg-sky-500',
    textColor: 'text-sky-900',
    sound: soundService.playDogSound,
  },
  {
    name: 'Sheep',
    emoji: '🐑',
    bgColor: 'bg-gray-200',
    hoverColor: 'hover:bg-gray-300',
    textColor: 'text-gray-800',
    sound: soundService.playSheepSound,
  },
  {
    name: 'Bird',
    emoji: '🐦',
    bgColor: 'bg-cyan-300',
    hoverColor: 'hover:bg-cyan-400',
    textColor: 'text-cyan-800',
    sound: soundService.playBirdSound,
  },
  {
    name: 'Pig',
    emoji: '🐖',
    bgColor: 'bg-pink-300',
    hoverColor: 'hover:bg-pink-400',
    textColor: 'text-pink-800',
    // Re-using cow sound with modification, but let's just use it directly for simplicity
    sound: soundService.playCowSound, 
  },
  {
    name: 'Frog',
    emoji: '🐸',
    bgColor: 'bg-green-400',
    hoverColor: 'hover:bg-green-500',
    textColor: 'text-green-900',
    sound: soundService.playDuckSound,
  }
];
