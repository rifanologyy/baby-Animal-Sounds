
import React from 'react';
import { Animal } from '../types';

interface AnimalCardProps {
  animal: Animal;
}

const AnimalCard: React.FC<AnimalCardProps> = ({ animal }) => {
  const cardClasses = `
    group
    relative
    flex
    flex-col
    items-center
    justify-center
    p-4
    rounded-3xl
    shadow-lg
    cursor-pointer
    transform
    transition-all
    duration-300
    ease-in-out
    focus:outline-none
    focus:ring-4
    focus:ring-offset-2
    focus:ring-offset-teal-100
    active:scale-95
    ${animal.bgColor}
    ${animal.hoverColor}
    focus:${animal.hoverColor.replace('hover:', '')}
  `;

  const handleClick = () => {
    // Ensure sound context is initialized by user gesture
    animal.sound();
  };

  return (
    <button onClick={handleClick} className={cardClasses}>
      <div className="text-7xl sm:text-8xl md:text-9xl transition-transform duration-300 group-hover:scale-110">
        {animal.emoji}
      </div>
      <span className={`mt-4 text-2xl font-semibold ${animal.textColor}`}>
        {animal.name}
      </span>
    </button>
  );
};

export default AnimalCard;
