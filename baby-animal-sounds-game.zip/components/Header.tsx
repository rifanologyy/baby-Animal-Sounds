
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="py-8 text-center">
      <h1 className="text-5xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500">
        Baby Animal Sounds
      </h1>
      <p className="text-gray-600 mt-2 text-lg">Click an animal to hear its sound!</p>
    </header>
  );
};

export default Header;
